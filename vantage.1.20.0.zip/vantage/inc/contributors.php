<?php
return json_decode( '{
	"b7122312e4008f8f2c76911080bca01a": {
		"name": "Andrew Misplon",
		"email": "b7122312e4008f8f2c76911080bca01a",
		"loc": 7466,
		"score": 148.79664522832178,
		"percent": 66.80380494574796
	},
	"5cff8d4385a469d1baab761889ad3161": {
		"name": "Alex S",
		"email": "5cff8d4385a469d1baab761889ad3161",
		"loc": 1621,
		"score": 69.36350451087785,
		"percent": 31.141468401978535
	},
	"85ce7a450a7ee4895f3bd823505e2e12": {
		"name": "adiraomj",
		"email": "85ce7a450a7ee4895f3bd823505e2e12",
		"loc": 1584,
		"score": 2.70913116079357,
		"percent": 1.2162926748811798
	},
	"43c0e7220c23bd6636cf5469be6e9612": {
		"name": "Braam Genis",
		"email": "43c0e7220c23bd6636cf5469be6e9612",
		"loc": 161,
		"score": 0.838515559662804,
		"percent": 0.37646030127718644
	},
	"36639e6e074b731b093bde5a77305179": {
		"name": "Braam Genis",
		"email": "36639e6e074b731b093bde5a77305179",
		"loc": 575,
		"score": 0.33059093417377994,
		"percent": 0.1484222460089054
	},
	"be6a5d2323cfe9ec8246b7a677dbc65b": {
		"name": "Aaron Evans",
		"email": "be6a5d2323cfe9ec8246b7a677dbc65b",
		"loc": 22,
		"score": 0.23128151299313884,
		"percent": 0.10383624615893082
	},
	"9e7a3b2d24c2b15c53209ba8e7b4e724": {
		"name": "Kevin Batdorf",
		"email": "9e7a3b2d24c2b15c53209ba8e7b4e724",
		"loc": 22,
		"score": 0.20807083580981328,
		"percent": 0.09341557068715298
	},
	"d1bea7e3f82e561c135bf5a3d4f9f896": {
		"name": "SiteOrigin Support",
		"email": "d1bea7e3f82e561c135bf5a3d4f9f896",
		"loc": 13,
		"score": 0.13548988051167848,
		"percent": 0.060829594215220016
	},
	"d203744279876c5eda043108e2611648": {
		"name": "Alex S",
		"email": "d203744279876c5eda043108e2611648",
		"loc": 19,
		"score": 0.08450650345400867,
		"percent": 0.03794007562956965
	},
	"a885c7bd5442dd2acd8c3e42001332c6": {
		"name": "Alex S",
		"email": "a885c7bd5442dd2acd8c3e42001332c6",
		"loc": 18,
		"score": 0.0332474025629334,
		"percent": 0.014926767954740225
	},
	"07294cc1dd7658895e44c559dfffd76f": {
		"name": "gpriday",
		"email": "07294cc1dd7658895e44c559dfffd76f",
		"loc": 18,
		"score": 0.00579822924452333,
		"percent": 0.0026031754606261883
	}
}', true );